package iiitb.timesheet.action;





public class Admin {

	public String execute(){
		return "success";
	}
}
